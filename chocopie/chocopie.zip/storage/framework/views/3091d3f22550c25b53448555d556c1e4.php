<div class="row mb-4">
    <div class="col-md-8">
        <h2 class="section-title">Tất Cả Truyện</h2>
    </div>
    <div class="col-md-4">
        <form action="<?php echo e(route('user.stories.index')); ?>" method="GET" class="d-flex flex-column gap-2">
            <!-- Search input -->
            <div class="input-group mb-2">
                <input type="text" name="search" class="form-control" 
                       placeholder="Tìm truyện theo tên hoặc hashtag (#tag)..." 
                       value="<?php echo e(request('search')); ?>">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i>
                </button>
            </div>
            
            <!-- Existing filters -->
            <div class="d-flex gap-2">
                <select name="category" class="form-select" id="categoryFilter">
                    <option value="">Tất cả thể loại</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="sort" class="form-select" id="sortOrder">
                    <option value="newest" <?php echo e(request('sort') == 'newest' || !request('sort') ? 'selected' : ''); ?>>Mới nhất</option>
                    <option value="oldest" <?php echo e(request('sort') == 'oldest' ? 'selected' : ''); ?>>Cũ nhất</option>
                    <option value="most_viewed" <?php echo e(request('sort') == 'most_viewed' ? 'selected' : ''); ?>>Xem nhiều nhất</option>
                </select>
            </div>
        </form>
    </div>
</div><?php /**PATH D:\duanwebncao\chocopie\resources\views/user/stories/partials/filters.blade.php ENDPATH**/ ?>