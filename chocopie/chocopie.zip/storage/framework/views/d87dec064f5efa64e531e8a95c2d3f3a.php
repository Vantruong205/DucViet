<div id="mainCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <?php $__currentLoopData = $featuredStories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" 
                    data-bs-target="#mainCarousel" 
                    data-bs-slide-to="<?php echo e($key); ?>" 
                    class="<?php echo e($loop->first ? 'active' : ''); ?>"
                    aria-current="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                    aria-label="Slide <?php echo e($key + 1); ?>">
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="carousel-inner rounded">
        <?php $__empty_1 = true; $__currentLoopData = $featuredStories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                <a href="<?php echo e(route('stories.show', $story->id)); ?>">
                    <?php if($story->cover_image): ?>
                        <img src="<?php echo e(Storage::url($story->cover_image)); ?>" 
                             class="d-block w-100" 
                             alt="<?php echo e($story->name); ?>"
                             style="height: 400px; object-fit: cover;">
                    <?php else: ?>
                        <div class="bg-secondary d-flex align-items-center justify-content-center" style="height: 400px;">
                            <i class="fas fa-book fa-3x text-white"></i>
                        </div>
                    <?php endif; ?>
                    <div class="carousel-caption">
                        <h3><?php echo e($story->name); ?></h3>
                        <p><?php echo e(Str::limit($story->description, 100)); ?></p>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="carousel-item active">
                <div class="bg-secondary d-flex align-items-center justify-content-center" style="height: 400px;">
                    <div class="text-white text-center">
                        <i class="fas fa-book fa-3x mb-3"></i>
                        <h3>Chưa có truyện nổi bật</h3>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div><?php /**PATH D:\duanwebncao\chocopie\resources\views/user/stories/partials/carousel.blade.php ENDPATH**/ ?>