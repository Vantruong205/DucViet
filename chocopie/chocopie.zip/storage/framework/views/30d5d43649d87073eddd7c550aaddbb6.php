<?php $__env->startSection('title', 'Chỉnh Sửa Truyện'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Chỉnh Sửa Truyện</h1>
        <div>
            <a href="<?php echo e(route('admin.stories')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Quay lại danh sách
            </a>
            <a href="<?php echo e(route('admin.stories.show', $story->id)); ?>" class="btn btn-info">
                <i class="fas fa-eye"></i> Xem chi tiết
            </a>
        </div>
    </div>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.stories.update', $story->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <div class="row mb-4">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label class="form-label">Tên truyện<span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control" required value="<?php echo e(old('name', $story->name)); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Mô tả<span class="text-danger">*</span></label>
                                    <textarea name="summary" class="form-control" rows="3" required><?php echo e(old('summary', $story->summary)); ?></textarea>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Ảnh bìa</label>
                                <div class="cover-preview text-center mb-2">
                                    <?php if($story->cover_image): ?>
                                        <img id="coverPreview" src="<?php echo e(Storage::url($story->cover_image)); ?>" class="img-fluid">
                                    <?php else: ?>
                                        <img id="coverPreview" src="#" class="img-fluid d-none">
                                        <div id="coverPlaceholder">
                                            <i class="fas fa-image fa-3x text-muted"></i>
                                            <p class="mt-2 text-muted">Chọn ảnh bìa</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <input type="file" name="cover_image" id="coverInput" class="form-control" accept="image/*">
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Nội dung truyện<span class="text-danger">*</span></label>
                            <textarea name="content" class="form-control" rows="10" required><?php echo e(old('content', $story->content)); ?></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Thể loại<span class="text-danger">*</span></label>
                                <select name="category_ids[]" class="form-select select2" multiple required>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" 
                                            <?php echo e(in_array($category->id, $story->categories->pluck('id')->toArray()) ? 'selected' : ''); ?>>
                                            <?php echo e($category->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <small class="text-muted mt-2 d-block">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Có thể chọn nhiều thể loại
                                </small>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Từ khóa</label>
                                <input type="text" id="tagInput" class="form-control" placeholder="Nhấn Enter để thêm từ khóa">
                                <div class="tags-container mt-2">
                                    <?php $__currentLoopData = $story->hashtags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hashtag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge bg-secondary me-1 mb-1 p-2">
                                            #<?php echo e($hashtag->name); ?>

                                            <i class="fas fa-times ms-1 text-danger" style="cursor:pointer" 
                                               onclick="removeTag('<?php echo e($hashtag->name); ?>')"></i>
                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <input type="hidden" name="hashtags" id="hashtagInput" 
                                       value="<?php echo e($story->hashtags->pluck('name')->implode(',')); ?>">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Độ tuổi</label>
                                <select name="age_rating" class="form-select">
                                    <option value="all" <?php echo e($story->age_rating == 'all' ? 'selected' : ''); ?>>Mọi lứa tuổi</option>
                                    <option value="13+" <?php echo e($story->age_rating == '13+' ? 'selected' : ''); ?>>13+</option>
                                    <option value="16+" <?php echo e($story->age_rating == '16+' ? 'selected' : ''); ?>>16+</option>
                                    <option value="18+" <?php echo e($story->age_rating == '18+' ? 'selected' : ''); ?>>18+</option>
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">Trạng thái</label>
                                <select name="status" class="form-select">
                                    <option value="draft" <?php echo e($story->status == 'draft' ? 'selected' : ''); ?>>Bản nháp</option>
                                    <option value="pending" <?php echo e($story->status == 'pending' ? 'selected' : ''); ?>>Đang chờ duyệt</option>
                                    <option value="published" <?php echo e($story->status == 'published' ? 'selected' : ''); ?>>Đã xuất bản</option>
                                    <option value="rejected" <?php echo e($story->status == 'rejected' ? 'selected' : ''); ?>>Đã từ chối</option>
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">Ngôn ngữ</label>
                                <select name="language" class="form-select">
                                    <option value="vi" <?php echo e($story->language == 'vi' ? 'selected' : ''); ?>>Tiếng Việt</option>
                                    <option value="en" <?php echo e($story->language == 'en' ? 'selected' : ''); ?>>Tiếng Anh</option>
                                </select>
                            </div>
                        </div>

                        <div class="text-end mt-4">
                            <button type="submit" class="btn btn-primary btn-lg px-5">
                                <i class="fas fa-save me-2"></i>Lưu thay đổi
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        // Initialize Select2
        $('.select2').select2({
            theme: 'bootstrap-5',
            placeholder: 'Chọn thể loại',
            width: '100%'
        });
        
        // Image preview handling
        $('#coverInput').change(function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    $('#coverPreview').attr('src', e.target.result).removeClass('d-none');
                    $('#coverPlaceholder').addClass('d-none');
                };
                reader.readAsDataURL(file);
            }
        });
        
        // Hashtag handling
        let tags = $('#hashtagInput').val() ? $('#hashtagInput').val().split(',') : [];
        
        $('#tagInput').on('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ',') {
                e.preventDefault();
                const tag = $(this).val().trim();
                
                if (tag && !tags.includes(tag)) {
                    tags.push(tag);
                    updateTags();
                }
                
                $(this).val('');
            }
        });
        
        // Function to update tags
        function updateTags() {
            $('#hashtagInput').val(tags.join(','));
            
            const container = $('.tags-container').empty();
            tags.forEach(tag => {
                container.append(`
                    <span class="badge bg-secondary me-1 mb-1 p-2">
                        #${tag}
                        <i class="fas fa-times ms-1 text-danger" style="cursor:pointer" onclick="removeTag('${tag}')"></i>
                    </span>
                `);
            });
        }
        
        // Expose removeTag function to global scope
        window.removeTag = function(tag) {
            const index = tags.indexOf(tag);
            if (index !== -1) {
                tags.splice(index, 1);
                updateTags();
            }
        };
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\duanwebncao\chocopie\resources\views/admin/stories/edit.blade.php ENDPATH**/ ?>