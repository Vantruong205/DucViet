<?php $__env->startSection('title', 'Chi Tiết Truyện'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Chi Tiết Truyện: <?php echo e($story->name); ?></h1>
        <div>
            <a href="<?php echo e(route('admin.stories')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Quay lại
            </a>
            <a href="<?php echo e(route('admin.stories.edit', $story->id)); ?>" class="btn btn-primary">
                <i class="fas fa-edit"></i> Chỉnh sửa
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Nội dung truyện</h5>
                </div>
                <div class="card-body">
                    <?php if($story->cover_image): ?>
                    <div class="text-center mb-4">
                        <img src="<?php echo e(Storage::url($story->cover_image)); ?>" class="img-fluid rounded" style="max-height: 300px;" alt="<?php echo e($story->name); ?>">
                    </div>
                    <?php endif; ?>

                    <h3><?php echo e($story->name); ?></h3>
                    <p class="text-muted">Tác giả: <?php echo e($story->author->name); ?></p>
                    
                    <h5>Mô tả:</h5>
                    <div class="mb-4"><?php echo e($story->summary); ?></div>
                    
                    <h5>Nội dung:</h5>
                    <div class="story-content">
                        <?php echo e($story->content); ?>

                    </div>
                </div>
            </div>
            
            <?php if($story->comments && $story->comments->count() > 0): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Bình luận (<?php echo e($story->comments->count()); ?>)</h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $story->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="comment mb-3 pb-3 border-bottom">
                        <div class="d-flex justify-content-between">
                            <h6><?php echo e($comment->user->name); ?></h6>
                            <small class="text-muted"><?php echo e($comment->created_at->format('d/m/Y H:i')); ?></small>
                        </div>
                        <p class="mb-0"><?php echo e($comment->content); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Thông tin chi tiết</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between">
                            <span>ID:</span>
                            <span><?php echo e($story->id); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Trạng thái:</span>
                            <span>
                                <?php if($story->status == 'draft'): ?>
                                    <span class="badge bg-secondary">Bản nháp</span>
                                <?php elseif($story->status == 'pending'): ?>
                                    <span class="badge bg-warning text-dark">Đang chờ duyệt</span>
                                <?php elseif($story->status == 'published'): ?>
                                    <span class="badge bg-success">Đã xuất bản</span>
                                <?php elseif($story->status == 'rejected'): ?>
                                    <span class="badge bg-danger">Đã từ chối</span>
                                <?php endif; ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Độ tuổi:</span>
                            <span><?php echo e($story->age_rating); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Ngôn ngữ:</span>
                            <span><?php echo e($story->language == 'vi' ? 'Tiếng Việt' : 'Tiếng Anh'); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Lượt xem:</span>
                            <span><?php echo e($story->views ?? 0); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Ngày tạo:</span>
                            <span><?php echo e($story->created_at->format('d/m/Y H:i')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Cập nhật cuối:</span>
                            <span><?php echo e($story->updated_at->format('d/m/Y H:i')); ?></span>
                        </li>
                        <li class="list-group-item">
                            <span>Thể loại:</span>
                            <div class="mt-2">
                                <?php $__currentLoopData = $story->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-info me-1"><?php echo e($category->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                        <?php if($story->hashtags && $story->hashtags->count() > 0): ?>
                        <li class="list-group-item">
                            <span>Từ khóa:</span>
                            <div class="mt-2">
                                <?php $__currentLoopData = $story->hashtags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-secondary me-1"><?php echo e($tag->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0">Quản lý</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.stories.destroy', $story->id)); ?>" method="POST" onsubmit="return confirm('Bạn có chắc chắn muốn xóa truyện này? Hành động này không thể hoàn tác.');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger w-100">
                            <i class="fas fa-trash"></i> Xóa truyện này
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\duanwebncao\chocopie\resources\views/admin/stories/show.blade.php ENDPATH**/ ?>