<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <style>
        .story-card {
            transition: transform 0.2s;
            border: none;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .story-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.15);
        }
        .story-cover-container {
            position: relative;
            width: 100%;
            padding-top: 130%; /* Reduced height ratio */
            overflow: hidden;
            border-radius: 4px 4px 0 0;
        }
        .story-cover {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .category-badge {
            background: linear-gradient(45deg, #0d6efd, #0dcaf0);
            font-size: 0.7rem;
            padding: 0.2rem 0.4rem;
            margin: 0.1rem;
            border-radius: 10px;
        }
        .carousel-item img {
            height: 400px;
            object-fit: cover;
        }
        .section-title {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #e9ecef;
        }
        .card-body {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .story-categories {
            margin-bottom: 10px;
        }
        .story-stats {
            margin-top: auto;
        }
        /* Mobile optimization */
        @media (max-width: 576px) {
            .story-stats {
                font-size: 0.7rem;
            }
        }
    </style>
</head>
<body class="bg-light">
    <?php if (isset($component)) { $__componentOriginal041c39339259bee048256900f20e1dfb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal041c39339259bee048256900f20e1dfb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar-login','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar-login'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal041c39339259bee048256900f20e1dfb)): ?>
<?php $attributes = $__attributesOriginal041c39339259bee048256900f20e1dfb; ?>
<?php unset($__attributesOriginal041c39339259bee048256900f20e1dfb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal041c39339259bee048256900f20e1dfb)): ?>
<?php $component = $__componentOriginal041c39339259bee048256900f20e1dfb; ?>
<?php unset($__componentOriginal041c39339259bee048256900f20e1dfb); ?>
<?php endif; ?>

    <!-- Main Content -->
    <div class="container py-4">
        <?php echo $__env->make('user.stories.partials.carousel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
        <?php echo $__env->make('user.stories.partials.filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
        <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-5 g-2">
            <?php $__empty_1 = true; $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col">
                    <div class="card story-card h-100">
                        <div class="story-cover-container">
                            <a href="<?php echo e(route('stories.show', $story->id)); ?>">
                                <?php if($story->cover_image): ?>
                                    <img src="<?php echo e(Storage::url($story->cover_image)); ?>" class="story-cover" alt="<?php echo e($story->name); ?>">
                                <?php else: ?>
                                    <div class="story-cover bg-secondary d-flex align-items-center justify-content-center">
                                        <i class="fas fa-book text-white"></i>
                                    </div>
                                <?php endif; ?>
                            </a>
                        </div>
                        <div class="card-body p-2">
                            <h6 class="card-title mb-1 text-truncate">
                                <a href="<?php echo e(route('stories.show', $story->id)); ?>" class="text-decoration-none text-dark">
                                    <?php echo e($story->name); ?>

                                </a>
                            </h6>
                            <div class="author-info mb-1 small text-truncate">
                                <i class="fas fa-user-edit me-1"></i><?php echo e($story->author->name); ?>

                            </div>
                            <div class="story-stats d-flex justify-content-between text-muted small">
                                <span><i class="fas fa-eye me-1"></i><?php echo e($story->views ?? 0); ?></span>
                                <span><i class="fas fa-clock me-1"></i><?php echo e($story->created_at->diffForHumans(null, true)); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="text-center py-5">
                        <i class="fas fa-book-open fa-3x mb-3 text-muted"></i>
                        <p class="text-muted">Chưa có truyện nào được đăng tải.</p>
                        <a href="<?php echo e(route('user.stories.create')); ?>" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i>Tạo Truyện Mới
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="d-flex justify-content-center mt-4">
            <?php echo e($stories->links()); ?>

        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH D:\duanwebncao\chocopie\resources\views/user/stories/index.blade.php ENDPATH**/ ?>