<?php $__env->startSection('title', 'Quản Lý Truyện'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Quản Lý Truyện Ngắn</h1>
</div>

<div class="card mb-4">
    <div class="card-header">
        <h5>Bộ Lọc</h5>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.stories')); ?>" method="GET" class="form-inline">
            <div class="form-group mr-3 mb-2">
                <label for="category" class="mr-2">Thể loại:</label>
                <select name="category" id="category" class="form-control form-control-sm">
                    <option value="">Tất cả</option>
                    
                    <?php $__currentLoopData = App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
            </div>
            
            <div class="form-group mr-3 mb-2">
                <label for="sort" class="mr-2">Sắp xếp:</label>
                <select name="sort" id="sort" class="form-control form-control-sm">
                    <option value="newest" <?php echo e(request('sort') == 'newest' || !request('sort') ? 'selected' : ''); ?>>Mới nhất</option>
                    <option value="oldest" <?php echo e(request('sort') == 'oldest' ? 'selected' : ''); ?>>Cũ nhất</option>
                    <option value="name_asc" <?php echo e(request('sort') == 'name_asc' ? 'selected' : ''); ?>>Tên A-Z</option>
                    <option value="name_desc" <?php echo e(request('sort') == 'name_desc' ? 'selected' : ''); ?>>Tên Z-A</option>
                </select>
            </div>

            <div class="form-group mr-3 mb-2">
                <label for="search" class="mr-2">Tìm kiếm:</label>
                <input type="text" name="search" id="search" class="form-control form-control-sm" value="<?php echo e(request('search')); ?>" placeholder="Tên truyện...">
            </div>
            
            <button type="submit" class="btn btn-sm btn-primary mb-2">
                <i class="fas fa-filter"></i> Lọc
            </button>
            <a href="<?php echo e(route('admin.stories')); ?>" class="btn btn-sm btn-secondary mb-2 ml-2">
                <i class="fas fa-sync"></i> Đặt lại
            </a>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5>Danh Sách Truyện</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên Truyện</th>
                    <th>Tác Giả</th>
                    <th>Thể loại</th>
                    <th>Ngày Tạo</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($story->id); ?></td>
                        <td><?php echo e($story->name); ?></td>
                        <td><?php echo e($story->author->name); ?></td>
                        <td>
                            <?php $__currentLoopData = $story->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-info"><?php echo e($category->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($story->created_at->format('d/m/Y')); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.stories.show', $story->id)); ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <form class="delete-form d-inline" action="<?php echo e(route('admin.stories.destroy', $story->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">Không có truyện nào</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="mt-4">
            <?php echo e($stories->appends(request()->query())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        // Handle story deletion
        $('.delete-form').on('submit', function(e) {
            e.preventDefault();
            
            if (confirm('Bạn có chắc chắn muốn xóa truyện này?')) {
                const form = $(this);
                const row = form.closest('tr');
                
                $.ajax({
                    url: form.attr('action'),
                    type: 'POST',
                    data: form.serialize(),
                    dataType: 'json',
                    success: function(result) {
                        if (result.success) {
                            // Xóa dòng khỏi bảng hoặc làm mới trang
                            row.fadeOut(function() {
                                $(this).remove();
                            });
                        } else {
                            alert('Lỗi: ' + result.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error details:', xhr.responseText);
                        alert('Đã xảy ra lỗi khi xóa truyện: ' + (xhr.responseJSON?.message || 'Lỗi không xác định'));
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\duanwebncao\chocopie\resources\views/admin/stories/index.blade.php ENDPATH**/ ?>