<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập / Đăng ký</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>
<body>
    <div class="container">
        <div class="left-side">
            <div class="left-content">
                <h2>Bạn chưa có tài khoản ?</h2>
                <p>Hãy đăng ký tài khoản ngay để đọc hàng ngàn bộ truyện tranh miễn phí.</p>
                <a href="<?php echo e(route('register')); ?>">
                    <button class="button">
                        <div><span>Đăng Ký</span></div>
                    </button>
                </a>
                <img src="<?php echo e(asset('images/anh_trai.png')); ?>" alt="Trái">
            </div>
        </div>
        <div class="right-side">
            <div class="login-content">
                <h2>Đăng nhập</h2>
                <div class="profile-image">
                <img src="<?php echo e(asset('images/anh_phai.png')); ?>" alt="Phải">
                </div>
                
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="input-group">
                        <input type="password" name="password" placeholder="Password" required>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn">
                        <span>Đăng nhập</span>
                    </button>
                    <div class="register-option mobile-only">
                        <p>Chưa có tài khoản? <a href="<?php echo e(route('register')); ?>" class="register-link">Đăng ký ngay</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH D:\duanwebncao\chocopie\resources\views/login.blade.php ENDPATH**/ ?>